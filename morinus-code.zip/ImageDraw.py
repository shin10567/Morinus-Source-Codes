# -*- coding: utf-8 -*-
# Shim: old "import ImageDraw" -> Pillow's PIL.ImageDraw
from PIL.ImageDraw import *
