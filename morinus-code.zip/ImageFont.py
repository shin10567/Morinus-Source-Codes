# -*- coding: utf-8 -*-
# Shim: old "import ImageFont" -> Pillow's PIL.ImageFont
from PIL.ImageFont import *
